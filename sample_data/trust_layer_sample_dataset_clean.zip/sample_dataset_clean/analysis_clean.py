import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.model_selection import cross_val_score, GroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

X = pd.read_csv("expression_matrix.csv").drop(columns=["sample_id"])
meta = pd.read_csv("sample_metadata.csv")
y = (meta["diagnosis"] == "disease").astype(int)
groups = meta["patient_id"]          # keep each patient's replicates together

# ALL preprocessing lives INSIDE the pipeline, so it is re-fit on each training fold only
pipe = Pipeline([
    ("scale",  StandardScaler()),
    ("select", SelectKBest(f_classif, k=20)),
    ("clf",    LogisticRegression(max_iter=2000)),
])

# group-aware CV: no patient appears in both train and test
cv = GroupKFold(n_splits=5)
scores = cross_val_score(pipe, X, y, groups=groups, cv=cv, scoring="roc_auc")
print("Honest AUC:", scores.mean())
