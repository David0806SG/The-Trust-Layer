# Trust-Layer Report

*Generated 2026-07-09. One automated pass: your code and your data
are both audited for leakage, an honest leakage-safe cross-validation is re-run,
and a calibrated LogReg(calibrated) model reports what the data can really
support.*

---

## The one-line answer

A naive analysis of this dataset reports **AUC 0.98**. After closing every
leak we could find, the honest performance is **AUC 0.98** — the
**+0.01 AUC** difference was inflation, not biology.

---

## 1. Code audit (sample_dataset_clean/analysis_clean.py)

**No leakage patterns found in the code.** 
- Group-aware splitting detected (GroupKFold).

## 2. Data audit

Dataset: **140 samples · 300 features** (p/n = 2.1). Batch–outcome confounding: Cramér's V = 0.03.

**0 critical**, **1 warning**:

| Check | Severity | Finding |
|---|---|---|
| dimensionality | **WARNING** | High-dimensional small-n regime: 300 features vs 140 samples (p/n = 2.1). Univariate feature selection on the full dataset will find spurious signal; nested CV is mandatory. |

## 3. How each leak inflated the score

| Cross-validation | AUC |
|---|---|
| Naive (preprocessing + selection on full data, random split) | 0.98 ± 0.02 |
| Subject-safe (GroupKFold on subject ID) | 0.98 ± 0.01 |
| Fully honest (+ in-fold batch centering) | 0.99 ± 0.01 |

## 4. Honest performance with calibrated uncertainty

**LogReg(calibrated)** fit with leakage-safe, group-aware out-of-fold prediction:

- **Honest AUC = 0.98** (vs 0.98 naive)
- **Brier score = 0.07** — lower is better; 0.25 is uninformative. A well-calibrated model's stated probabilities can be trusted, not just its labels.

## 5. What to do

1. **Report the honest number (0.98), not the naive one** — and state that CV was group-aware with all preprocessing fit inside folds.

---
*No code from the audited notebook was executed. Honest CV uses GroupKFold on subject ID with scaling, feature selection, and per-batch centering all fit inside each training fold. Probabilities are read from out-of-fold predictions.*

## Hyperparameter-selection honesty (nested CV)

Tuning the model (feature count + regularization) on the whole dataset and reporting the best cross-validated score is itself a mild leak. Nested CV — tuning inside each outer training fold only — removes it:

| Estimate | AUC |
|---|---|
| Flat GridSearch best score (optimistic) | 1.00 |
| Nested CV (honest) | 1.00 ± 0.00 |

Tuning optimism = **+0.00 AUC**.
