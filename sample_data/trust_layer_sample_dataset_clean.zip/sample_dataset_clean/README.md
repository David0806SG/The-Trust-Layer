# Clean counterpart — the "no inflation" case

The companion to the leaky sample dataset. Everything here is done **correctly**,
so the trust layer should find nothing to flag and report that the naive score is
already honest. This is the control case that proves the tool doesn't cry wolf.

## What makes it clean

| | Leaky sample | **This (clean)** |
|---|---|---|
| Subjects | 40 patients × 4 replicates (leakage) | **140 unique patients, 1 sample each** |
| Batch | plate confounded with diagnosis (V≈0.67) | **plate independent of diagnosis (V≈0.03)** |
| Analysis code | scaling + selection before split, plain KFold | **Pipeline + GroupKFold (all fit inside folds)** |
| Real signal | 25 features, present | 20 features, present (modest) |

## Files

- `expression_matrix.csv` — 140 samples × 300 protein features
- `sample_metadata.csv`   — `sample_id`, `diagnosis`, `patient_id` (all unique), `plate`, `replicate`
- `analysis_clean.py`     — a leak-safe analysis: `Pipeline([scale, select, clf])` + `GroupKFold`

## Run it

```python
import pandas as pd
from trust_audit import trust_audit

X    = pd.read_csv("expression_matrix.csv").drop(columns=["sample_id"])
meta = pd.read_csv("sample_metadata.csv")
y    = (meta["diagnosis"] == "disease").astype(int)

result = trust_audit(X, y, groups=meta["patient_id"], batch=meta["plate"],
                     notebook="analysis_clean.py")
print(result["report_md"])
```

## Expected result (verified)

| | |
|---|---|
| Code audit | **0 critical** — Pipeline + GroupKFold recognised as leak-safe |
| Data audit | **0 critical** — subject leakage, batch confound, leaky selection, leaky preprocessing all **OK** (one dimensionality *warning*, honest: p > n regime) |
| CV ladder | naive **0.98** → subject-safe **0.98** → fully honest **0.99** — flat across all three rungs |
| Honest model | Calibrated logistic regression, **AUC 0.98**, Brier 0.07 |
| **Verdict** | Inflation (naive − honest model AUC) = **+0.00** — the reported score was already trustworthy. No leakage to correct. |

Contrast with the leaky sample, where the same tool reports **+0.08 inflation**
and four critical findings. Same tool, opposite verdict — because the analysis is
actually sound.
