import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.model_selection import cross_val_score, KFold
from sklearn.linear_model import LogisticRegression

X = pd.read_csv("expression_matrix.csv").drop(columns=["sample_id"])
meta = pd.read_csv("sample_metadata.csv")
y = (meta["diagnosis"] == "disease").astype(int)
patient_id = meta["patient_id"]

# scale on the full data
scaler = StandardScaler()
Xs = scaler.fit_transform(X)

# pick the 20 best features on the full data
sel = SelectKBest(f_classif, k=20)
Xsel = sel.fit_transform(Xs, y)

# cross-validate (not group-aware, despite repeated patients)
clf = LogisticRegression(max_iter=2000)
cv = KFold(n_splits=5, shuffle=True, random_state=0)
scores = cross_val_score(clf, Xsel, y, cv=cv, scoring="roc_auc")
print("AUC:", scores.mean())
