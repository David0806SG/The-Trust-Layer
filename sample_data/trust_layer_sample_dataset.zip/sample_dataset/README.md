# Sample validation dataset — binary use case

A ready-to-run dataset for demonstrating the **Trust Layer** on a binary
classification problem. It is synthetic but built to look like a real serum
proteomics biomarker study, with **three data-leakage traps deliberately baked in**
so the audit has something to find. Ground truth is known, so every number the
tool reports can be checked.

## Files

| File | What it is |
|---|---|
| `expression_matrix.csv` | 160 samples × 800 protein features (`PROT_0000`…`PROT_0799`), plus a `sample_id` column. Log-scale abundances. |
| `sample_metadata.csv`   | One row per sample: `sample_id`, `diagnosis` (disease/control), `patient_id`, `plate`, `replicate`. |
| `analysis_leaky.py`     | A typical (flawed) analysis script — the kind a scientist would actually write. Feed it to the code audit. |
| `trust_out/`            | The trust report + JSON produced by running the audit on these files. |

## The three traps (ground truth)

1. **Subject leakage** — 40 patients, **4 replicate samples each** (160 rows). A
   random split puts the same patient on both sides.
2. **Batch confounding** — `plate` is correlated with `diagnosis` (plate_2 is
   mostly disease). A model can score high by reading the plate, not the biology.
3. **High-dimensional** — 800 features vs 160 samples (p/n = 5). Feature selection
   on the full data manufactures signal.

Real signal is present too: **25 features** carry a genuine
disease effect (1.3 SD), so honest performance is well above
chance — the tool should separate the real signal from the inflation.

## Run it

```python
import pandas as pd
from trust_audit import trust_audit          # or load the small-data-leakage-audit skill

X    = pd.read_csv("expression_matrix.csv").drop(columns=["sample_id"])
meta = pd.read_csv("sample_metadata.csv")
y    = (meta["diagnosis"] == "disease").astype(int)

result = trust_audit(
    X, y,
    groups   = meta["patient_id"],   # closes subject leakage
    batch    = meta["plate"],        # checks + corrects batch confound
    notebook = "analysis_leaky.py",  # static code audit
)
print(result["report_md"])
```

## Expected result (what the tool reports on this data)

| | |
|---|---|
| Code audit | **3 critical** — scaling, feature selection, and non-group CV all before the split |
| Data audit | **4 critical** — subject leakage, batch confound (Cramér's V ≈ 0.67), leaky selection, leaky preprocessing |
| CV ladder | naive **0.98** → subject-safe **0.94** → fully honest **0.89** |
| Honest model | Calibrated logistic regression, **AUC 0.90**, Brier 0.15 |
| **Verdict** | The reported 0.98 was inflated by **+0.08 AUC**; the real, trustworthy number is ~0.90 |
